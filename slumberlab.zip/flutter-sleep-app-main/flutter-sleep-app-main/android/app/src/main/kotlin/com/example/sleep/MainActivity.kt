package com.submission.sleep

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
