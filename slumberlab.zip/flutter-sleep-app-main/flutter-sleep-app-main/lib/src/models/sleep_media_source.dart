import 'package:sleep/src/models/sleep_media_model.dart';

List<SleepMediaItem> sleepMediaDataSource = [
  SleepMediaItem(
      title: 'lovely story',
      category: SleepMediaCategory(
        id: 1,
        name: 'Sleep Story',
      ),
      duration: "04:07",
      imgUrl: "https://i.ibb.co/r0Ln7Wc/image-akudansepi.jpg",
      description:
          "Fur & Feather Audio Story",
      mediaUrl:
          "https://storiestogrowby.org/wp-content/uploads/2016/03/Fur-Feather-Africa.mp3?_=1",
      totalFavorite: "312",
      totalListening: "5.412",
      isFavorited: false),
  SleepMediaItem(
      title: 'Mousey the merchant',
      category: SleepMediaCategory(
        id: 1,
        name: 'Sleep Story',
      ),
      duration: "03:33",
      imgUrl: "https://i.ibb.co/9qt8MYP/image-kapanmenikah.jpg",
      description:
          "Mousey the merchant",
      mediaUrl:
          "https://storiestogrowby.org/wp-content/uploads/edd/2015/09/Mousey-the-Merchant-India.mp3?_=1",
      totalFavorite: "412",
      totalListening: "6.123",
      isFavorited: false),

  SleepMediaItem(
    title: 'To The Stars',
    category: SleepMediaCategory(
      id: 2,
      name: 'Sleep Music',
    ),
    duration: "04:10",
    imgUrl: "https://i.ibb.co/fd28dZ3/To-the-Stars.jpg",
    description:
        "Don't ever stop reaching for the stars. Even if they remain out of reach, you'll still go further than if you didn't bother to try.",
    mediaUrl:
        "https://archive.org/download/forget-jakarta-adhitia-sofyan-original-audio-only/sleep%20music/To%20the%20Stars.mp3",
    totalFavorite: "3.752",
    totalListening: "92",
    isFavorited: false,
  ),
  SleepMediaItem(
    title: 'Novo Amor - Ontario',
    category: SleepMediaCategory(
      id: 2,
      name: 'Sleep Music',
    ),
    duration: "03:32",
    imgUrl: "https://i.ibb.co/nLGwDcs/maxresdefault.jpg",
    description:
        "Beristirahatlah saat Kamu lelah. Segarkan dan perbarui dirimu, tubuhmu, pikiranmu, jiwamu. Lalu, kembali bekerja.",
    mediaUrl:
        "https://archive.org/download/senar-senja-dialog-hujan/Ontario%20.mp3",
    totalFavorite: "1.752",
    totalListening: "8.300",
    isFavorited: false,
  ),
  SleepMediaItem(
    title: 'Dialog Hujan',
    category: SleepMediaCategory(
      id: 2,
      name: 'Sleep Music',
    ),
    duration: "03:32",
    imgUrl: "https://i.ibb.co/WHHBTMj/Dialog-Hujan.jpg",
    description:
        "Hujan selalu mengerti, meski dia jatuh berulang ulang tetapi dia selalu setia pada yang ia jatuhkan hatinya",
    mediaUrl:
        "https://archive.org/download/senar-senja-dialog-hujan/Senar%20Senja%20%20Dialog%20Hujan.mp3",
    totalFavorite: "75.000",
    totalListening: "7.204",
    isFavorited: false,
  ),
];
